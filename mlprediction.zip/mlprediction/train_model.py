from src.scoring_whitespace import *
from src.training_whitespace import *
import json

if __name__ == "__main__":
    try:
        # with open('src/ml_input.json', 'r') as file:
        #  data = json.load(file)
        # scoring_main(data)
        training_main()
    except Exception as err:
        print(str(err))
