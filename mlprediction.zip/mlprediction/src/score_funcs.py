"""
This module contains all the function definitions that are used to calculate string-matching scores/ratios.
"""

import joblib
import numpy as np
import pandas as pd

from sklearn import metrics
from rapidfuzz import fuzz

from sklearn.preprocessing import LabelEncoder
from sparse_dot_topn import awesome_cossim_topn
from sklearn.model_selection import cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from src.class_creation import *


def ngrams_3(string, n=3):
    """
    This function cleans a string and generates all 3-gram i.e. sequence of 3 contiguous characters.
    The terms in N-Grams are usually words, however in our case instead of using words,
    we are using characters as most company names only contain one or few words.

    Here we are adding a whitespace to the string that contains only single character, in order to avoid errors.
    """
    s = str(string)
    if len(s) < 3:
        string = string + ' ' + ' '
        s = str(string)
    ngrams = zip(*[s[i:] for i in range(n)])
    return [''.join(ngram) for ngram in ngrams]


def ngrams_2(string, n=2):
    """
    This function cleans a string and generates all 2-gram i.e. sequence of 2 contiguous characters.
    The terms in N-Grams are usually words, however in our case instead of using words,
    we are using characters as most company names only contain one or few words.

    Here we are adding a whitespace to the string that contains only single character, in order to avoid errors.
    """
    s = str(string)
    if len(s) < 2:
        string = string + ' '
        s = str(string)
    ngrams = zip(*[s[i:] for i in range(n)])
    return [''.join(ngram) for ngram in ngrams]


def funct_tfidf(df, ngrams):
    """
    Function to generate the matrix of TF-IDF values and check there cosine similarity and return the resulting matrix.
    """
    vectorizer = TfidfVectorizer(min_df=1, analyzer=ngrams)
    tf_idf_matrix = vectorizer.fit_transform(df.values.astype('U'))
    matches = awesome_cossim_topn(tf_idf_matrix, tf_idf_matrix.transpose(), 10, 0)
    return matches


def score_name(df, p1):
    """
    Function to calculate name match score and using numpy matrix functions to retrieve only 2 score needed
    i.e.Name1 vs Name2 score using both 2gram & 3gram
    :param df: Raw dataframe to calculate similarity score for names
    :param p1: Instance of a class "Columns"
    :return: Pandas data frame with fields contains similarity scores
    """
    name_matches = funct_tfidf(df[[p1.fullname1, p1.fullname2]], ngrams_2)
    m1 = name_matches[np.triu_indices(2, k=1)].tolist()
    df['2grm_name'] = m1[0][0]
    name_matches = funct_tfidf(df[[p1.fullname1, p1.fullname2]], ngrams_3)
    m2 = name_matches[np.triu_indices(2, k=1)].tolist()
    df['3grm_name'] = m2[0][0]
    return df


def score_addr(df, p1):
    """
    Function to calculate name + address match score and using numpy matrix functions to retrieve only 2 score needed
    i.e. Address1 vs Address2 scores using both 2gram & 3gram

    :param df: Raw dataframe to calculate similarity score for address
    :param p1: Instance of a class "Columns"
    :return: Pandas data frame with fields contains similarity scores
    """
    addr_matches = funct_tfidf(df[[p1.fulladdr1, p1.fulladdr2]], ngrams_3)
    n1 = addr_matches[np.triu_indices(2, k=1)].tolist()
    df['3grm_addr'] = n1[0][0]
    addr_matches = funct_tfidf(df[[p1.fulladdr1, p1.fulladdr2]], ngrams_2)
    n2 = addr_matches[np.triu_indices(2, k=1)].tolist()
    df['2grm_addr'] = n2[0][0]
    return df


def score_name_addr(df, p1):
    """
    Function to calculate name + address match score and using numpy matrix functions to retrieve only 2 score needed
    i.e. Name&Address1 vs Name&Address2 score using both 2gram & 3gram

    :param df: Raw dataframe to calculate similarity score for name&address combined
    :param p1: Instance of a class "Columns"
    :return: Pandas data frame with fields contains similarity scores
    """
    addr_matches = funct_tfidf(df[[p1.fullnameaddr1, p1.fullnameaddr2]], ngrams_3)
    n1 = addr_matches[np.triu_indices(2, k=1)].tolist()
    df['3grm_nameaddr'] = n1[0][0]
    addr_matches = funct_tfidf(df[[p1.fullnameaddr1, p1.fullnameaddr2]], ngrams_2)
    n2 = addr_matches[np.triu_indices(2, k=1)].tolist()
    df['2grm_nameaddr'] = n2[0][0]
    return df


def get_token_score_name(df, p1):
    """
    Function for calculating fuzz token sort ratio from Fuzzywuzzy for Name1 with Name2

    :param df: Raw dataframe to calculate similarity score for name
    :param p1: Instance of a class "Columns"
    :return: Similarity scores
    """
    return fuzz.token_sort_ratio(str(df[p1.fullname1]).upper(), str(df[p1.fullname2]).upper())/100


def get_token_score_nameaddr(df, p1):
    """
    Function for calculating fuzz token sort ratio from Fuzzywuzzy for Name&Address1 with Name&Address2

    :param df: Raw dataframe to calculate similarity score for name&address
    :param p1: Instance of a class "Columns"
    :return: Similarity scores
    """
    return fuzz.token_sort_ratio(str(df[p1.fullnameaddr1]).upper(), str(df[p1.fullnameaddr2]).upper())/100


def get_token_score_addr(df, p1):
    """
    Function for calculating fuzz token sort ratio from Fuzzywuzzy for Address1 with Address2

    :param df: Raw dataframe to calculate similarity score for address
    :param p1: Instance of a class "Columns"
    :return: Similarity scores
    """
    return fuzz.token_sort_ratio(str(df[p1.fulladdr1]).upper(), str(df[p1.fulladdr2]).upper())/100


def get_ratio_name(df, p1):
    """
    Function for calculating fuzz ratio from Fuzzywuzzy for Name1 with Name2

    :param df: Raw dataframe to calculate similarity score for name
    :param p1: Instance of a class "Columns"
    :return: Similarity scores
    """
    return fuzz.ratio(str(df[p1.fullname1]).upper(), str(df[p1.fullname2]).upper())/100


def get_ratio_nameaddr(df, p1):
    """
    Function for calculating fuzz ratio from Fuzzywuzzy for Name&Address1 with Name&Address2

    :param df: Raw dataframe to calculate similarity score for name&address
    :param p1: Instance of a class "Columns"
    :return: Similarity scores
    """
    return fuzz.ratio(str(df[p1.fullnameaddr1]).upper(), str(df[p1.fullnameaddr2]).upper())/100


def get_ratio_addr(df, p1):
    """
    Function for calculating fuzz ratio from Fuzzywuzzy for Address1 with Address2

    :param df: Raw dataframe to calculate similarity score for address
    :param p1: Instance of a class "Columns"
    :return: Similarity scores
    """
    return fuzz.ratio(str(df[p1.fulladdr1]).upper(), str(df[p1.fulladdr2]).upper())/100


def get_wratio_name(df, p1):
    """
    Function for calculating fuzz WRatio from Fuzzywuzzy for Name1 with Name2

    :param df: Raw dataframe to calculate similarity score for name
    :param p1: Instance of a class "Columns"
    :return: Similarity scores
    """
    return fuzz.WRatio(str(df[p1.fullname1]).upper(), str(df[p1.fullname2]).upper())/100


def get_wratio_nameaddr(df, p1):
    """
    Function for calculating fuzz WRatio from Fuzzywuzzy for Name&Address1 with Name&Address2

    :param df: Raw dataframe to calculate similarity score for Name&Address
    :param p1: Instance of a class "Columns"
    :return: Similarity scores
    """
    return fuzz.WRatio(str(df[p1.fullnameaddr1]).upper(), str(df[p1.fullnameaddr2]).upper())/100


def get_wratio_addr(df, p1):
    """
    Function for calculating fuzz WRatio from Fuzzywuzzy for Address1 with Address2

    :param df: Raw dataframe to calculate similarity score for Address
    :param p1: Instance of a class "Columns"
    :return: Similarity scores
    """
    return fuzz.WRatio(str(df[p1.fulladdr1]).upper(), str(df[p1.fulladdr2]).upper())/100


def prediction(df, models, pred_var, model_fd):
    """
    Function for calculating the probability score.

    :param df: Input data frame
    :param models: List of models to be executed
    :param pred_var: List of predictors
    :param model_fd: Folder where the trained models are saved
    This comes from the configuration file
    :return: Resulting data frame with input + predicted probability
    """
    out_df = pd.DataFrame()
    for model in models:
        clf = joblib.load(model_fd + model + '.pkl')
        predict_proba = clf.predict_proba(df[pred_var])
        out_df['A_Predicted_prob_' + model] = predict_proba[:, 0]
        out_df['N_Predicted_prob_' + model] = predict_proba[:, 1]
        out_df['Y_Predicted_prob_' + model] = predict_proba[:, 2]
    predicted_df = pd.concat([df.reset_index(drop=True), out_df], axis=1)
    return predicted_df


#  Training for 3-Label data
def training(df, models, pred_var, target_var, model_fd):
    """
    Function for training the data with list of models.
    :param df: Input data frame
    :param models: List of models to be trained on
    :param pred_var: List of predictors
    :param target_var: Target variable
    :param model_fd: Folder where the trained models are to be saved
    :return: Resulting data frame with input + predicted probability
    """
    final_df = pd.DataFrame()
    for key, model in models.items():
        print(model)
        out_df = classification_model(model, key, df, pred_var, target_var, model_fd).reset_index(drop=True)
        final_df = pd.concat([final_df, out_df], axis=1)
    trained_df = pd.concat([df.reset_index(drop=True), final_df], axis=1)
    return trained_df


def classification_model(model, key, data, predictors, target, model_fd):
    """
    Generic function for making a classification model and accessing performance.
    :param model: Algorithm from a dictionary
    :param key: Key from a dictionary w.r.t algorithm passed
    :param data: Input data
    :param predictors: List of predictors
    :param target: Target column
    :param model_fd: Folder path where the model pickle file is to be saved
    :return: Pandas data frame with input + predictions
    """

    le = LabelEncoder()
    data[target] = le.fit_transform(data[target])
    
    model.fit(data[predictors], data[target])
    print('model fitted')
    joblib.dump(model, open(model_fd + key + '.pkl', 'wb'))

    # Make predictions on training set:
    predictions = model.predict(data[predictors])

    # Predicted probability
    predictions_proba = model.predict_proba(data[predictors])
    print('model predicted')
    a_predict = predictions_proba[:, 0]
    n_predict = predictions_proba[:, 1]
    y_predict = predictions_proba[:, 2]
    print('model predict prob')
    # Calculating accuracy
    accuracy = metrics.accuracy_score(predictions, data[target])
    print("Accuracy : %s" % "{0:.2%}".format(accuracy))

    # Calculating accuracy using cross-validation method
    cv = 5
    mean_score = cross_val_score(model, data[predictors], data[target], scoring='accuracy', cv=cv).mean()
    print("{} mean_accuracy_score = {}".format(key, mean_score))

    model_output_df = pd.DataFrame({'Y_Predicted_prob_' + str(key): y_predict,
                                    'N_Predicted_prob_' + str(key): n_predict,
                                    'A_Predicted_prob_' + str(key): a_predict})

    return model_output_df


