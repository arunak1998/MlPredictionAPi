import os
import re
import time
import json
import warnings
import pandas as pd
import numpy as np
from src.score_funcs import *
from src.score_calculation import *
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from src.json_transformations import *
from rapidfuzz import fuzz
from sklearn.svm import SVC
from collections import OrderedDict


def data_transformation(df, p1):
    """
    a. Creating new columns for our processing
    b. Name Standardization applied: Converting French characters to English characters
    c. Address standardisation applied are:
        1) Converting French characters to English characters
        2) Remove all unneeded junk, i.e.everything but letters, numbers, spaces, single apostrophes, and forward slashes
        3) Remove stop words(only on addr_line_one, standardize_name already have the stop words removed)
        4) Remove 1 letter word
        5) Remove all street / avenue / boulevard / etc short ang longform, except ST
        6) Update SAINT, SAINTE and STE to ST
        7) Remove the word "ST" or "DR" if it appears at the very end of the string
        8) Update double++ spaces to 1 space
    """

    df[p1.fullname1] = df[p1.fullname1].astype('str').str.replace('nan', '', case=False) \
        .str.translate(str.maketrans('ÇÁÀÄÂÉÈËÊÍÌÏÎÓÒÖÔÚÙÜÛ', 'CAAAAEEEEIIIIOOOOUUUU')) \
        .str.replace(r"[^A-Za-z_0-9''\/\s]", " ", case=False) \
        .str.replace(r" CANADA$", "", case=False) \
        .str.upper()

    df[p1.fullname2] = df[p1.fullname2].astype('str').str.replace('nan', '', case=False) \
        .str.translate(str.maketrans('ÇÁÀÄÂÉÈËÊÍÌÏÎÓÒÖÔÚÙÜÛ', 'CAAAAEEEEIIIIOOOOUUUU')) \
        .str.replace(r"[^A-Za-z_0-9''\/\s]", " ", case=False) \
        .str.replace(r" CANADA$", "", case=False) \
        .str.upper()

    df[p1.fulladdr1] = df[p1.fulladdr1].astype('str').str.replace('nan', ' ', case=False) \
        .str.translate(str.maketrans('ÇÁÀÄÂÉÈËÊÍÌÏÎÓÒÖÔÚÙÜÛ', 'CAAAAEEEEIIIIOOOOUUUU')) \
        .str.replace(r"[^A-Za-z_0-9''\/\s]", " ", case=False) \
        .str.replace(r'(\b)(AN|AND|BRANCH|CO|DE|DES|DU|EN|ET|FOR|FP|LA|LE|LES|'
                     r'OF|SS|THE|TR|VM|ABM|BR|CC|IN|BOUL|BLV|BLVD|RD|BOULEVARD|'
                     r'RUE|STREET|AVE|AVENUE|AV|CH|CHEMIN|RTE|ROUTE|CRT|COURT'
                     r')(\b)', '', case=False) \
        .str.replace(r'\b[a-zA-Z]{1}\b', ' ', case=False) \
        .str.replace(r'\b(BUREAU|SUITE|UNIT)\b (\b[0-9]+\b)', ' ', case=False) \
        .str.replace(r'\b(SAINT|SAINTE|STE)\b', 'ST', case=False) \
        .str.replace(r'( ST| DR)$', '', case=False) \
        .str.replace(r'\s+', ' ', case=False) \
        .str.replace(r" CANADA$", "", case=False) \
        .str.upper()

    # to remove repeated parts of the address
    df[p1.fulladdr1] = df[p1.fulladdr1].str.split().apply(lambda x: ' '.join(OrderedDict.fromkeys(x).keys()))

    df[p1.fulladdr2] = df[p1.fulladdr2].astype('str').str.replace('nan', ' ', case=False) \
        .str.translate(str.maketrans('ÇÁÀÄÂÉÈËÊÍÌÏÎÓÒÖÔÚÙÜÛ', 'CAAAAEEEEIIIIOOOOUUUU')) \
        .str.replace(r"[^A-Za-z_0-9''\/\s]", " ", case=False) \
        .str.replace(r'(\b)(AN|AND|BRANCH|CO|DE|DES|DU|EN|ET|FOR|FP|LA|LE|LES|'
                     r'OF|SS|THE|TR|VM|ABM|BR|CC|IN|BOUL|BLV|BLVD|RD|BOULEVARD|'
                     r'RUE|STREET|AVE|AVENUE|AV|CH|CHEMIN|RTE|ROUTE|CRT|COURT'
                     r')(\b)', '', case=False) \
        .str.replace(r'\b[a-zA-Z]{1}\b', ' ', case=False) \
        .str.replace(r'\b(BUREAU|SUITE|UNIT)\b (\b[0-9]+\b)', ' ', case=False) \
        .str.replace(r'\b(SAINT|SAINTE|STE)\b', 'ST', case=False) \
        .str.replace(r'( ST| DR)$', '', case=False) \
        .str.replace(r'\s+', ' ', case=False) \
        .str.replace(r" CANADA$", "", case=False) \
        .str.upper()

    # to remove repeated parts of the address
    df[p1.fulladdr2] = df[p1.fulladdr2].str.split().apply(lambda x: ' '.join(OrderedDict.fromkeys(x).keys()))

    df['Name_Address_1'] = (df[p1.fullname1].astype('str').str.cat(df[[p1.fulladdr1]].astype('str'), sep=' ')
                            ).str.replace('nan', '', case=False)

    df['Name_Address_2'] = (df[p1.fullname2].astype('str').str.cat(df[[p1.fulladdr2]].astype('str'), sep=' ')
                            ).str.replace('nan', '', case=False)

    df[p1.contact1] = df[p1.contact1].str.strip()
    df[p1.contact2] = df[p1.contact2].str.strip()
    df[[p1.prntduns1,p1.ultprtduns1]] = df[[p1.prntduns1,p1.ultprtduns1]].astype(str)
    df[p1.prntduns1] = df[p1.prntduns1].str.strip()
    df[p1.prntduns2] = df[p1.prntduns2].str.strip()
    df[p1.ultprtduns1] = df[p1.ultprtduns1].str.strip()
    df[p1.ultprtduns2] = df[p1.ultprtduns2].str.strip()
    df[p1.phone1] = df[p1.phone1].str.strip()
    df[p1.phone2] = df[p1.phone2].str.strip()
    df[p1.url1] = df[p1.url1].str.strip()
    df[p1.url2] = df[p1.url2].str.strip()

    # Setting a new attribute of the instance
    setattr(p1, "fullnameaddr1", "Name_Address_1")
    setattr(p1, "fullnameaddr2", "Name_Address_2")

    return df, p1


def get_token_score_contname(df, p1):
    """
    Function for calculating fuzz token sort ratio from Fuzzywuzzy for Name1 with Name2

    :param df: Raw dataframe to calculate similarity score for name
    :param p1: Instance of a class "Columns"
    :return: Similarity scores
    """
    if (str(df[p1.contact1]) == '') & (str(df[p1.contact2]) == ''):
        return 0
    else:
        return fuzz.token_sort_ratio(str(df[p1.contact1]).upper(), str(df[p1.contact2]).upper()) / 100


def ensembe_score(df):
    """
    Function to flag the records based on FAP
    """
    a = ['Predicted_prob_LogisticRegression', 'Predicted_prob_RandomForestClassifier_50',
         'Predicted_prob_GradientBoostingClassifier_25', 'Predicted_prob_SupportVectorMachine_rbf'
         ]

    for i in ['N_', 'A_', 'Y_']:
        cols = [i + j for j in a]
        df[i + 'Finalprob'] = (df[cols[:4]].sum(axis=1)) / 4

    df['factor'] = 2 * df['Y_Finalprob'] + df['A_Finalprob'] + 0.5 * df['N_Finalprob']
    # Replacing df['factor'].min()=0.5 and df['factor'].max()=1.99 because we want to maintain the score consistency
    # irrespective of the size of the data
    # df['Final_Approval_Probability'] = (df['factor'] - df['factor'].min()) / (df['factor'].max() - df['factor'].min())
    df['Final_Approval_Probability'] = ((df['factor'] - 0.5) / (1.99 - 0.5))
    df['Final_Approval_Probability'] = np.where(
        df['Final_Approval_Probability'] > 1.0, 1.0, df['Final_Approval_Probability'])

    return df


def deterministics_boosting(df, p1):
    df['Flag_boosting'] = 0

    df.loc[(((df[p1.prntduns1] != '') & (df[p1.prntduns2] != '')) &
            ((df[p1.prntduns1] != 0) & (df[p1.prntduns2] != 0)) &
            (df[p1.prntduns1] == df[p1.prntduns2])), 'Flag_boosting'] += 0.1

    df.loc[(((df[p1.ultprtduns1] != '') & (df[p1.ultprtduns2] != '')) &
            ((df[p1.ultprtduns1] != 0) & (df[p1.ultprtduns2] != 0)) &
            (df[p1.ultprtduns1] == df[p1.ultprtduns2])), 'Flag_boosting'] += 0.1

    df.loc[((df[p1.phone1] != '') & (df[p1.phone2] != '')) &
           (df[p1.phone1] == df[p1.phone2]), 'Flag_boosting'] += 0.05

    df.loc[((df[p1.url1] != '') & (df[p1.url2] != '')) &
           (df[p1.url1] == df[p1.url2]), 'Flag_boosting'] += 0.05

    df.loc[(df['contactName_score'] >= 0.9), 'Flag_boosting'] += 0.05

    df['Final_Approval_Probability'] = df['Final_Approval_Probability'] + df['Flag_boosting']

    df['Final_Approval_Probability'] = np.where(
        df['Final_Approval_Probability'] > 1.0, 1.0, df['Final_Approval_Probability'])

    return df


def flags(df, ml_threshold_y_lower, ml_threshold_a_lower):
    choices = ['Y', 'A']
    conditions = [df['Final_Approval_Probability'] >= ml_threshold_y_lower,
                  ((df['Final_Approval_Probability'] < ml_threshold_y_lower) & (
                              df['Final_Approval_Probability'] >= ml_threshold_a_lower))]
    df['Predicted_flag'] = np.select(conditions, choices, default='N')

    return df



def scoring_main(data):
    start_time = time.time()
    warnings.filterwarnings("ignore")
    
    ml_threshold_y_lower = 0.90000
    ml_threshold_a_lower = 0.89998
    
    # Loading data
    df = json_to_dataframe(data)

    p1 = Columns_scoring(df.columns)
    print(df.info())
    print(p1)

    df1, p1 = data_transformation(df, p1)

    modified_df, p1 = name_match(df1, p1)

    print("Modelling...")

    pred_var = [
        'Ratio_name', 'Ratio_nameaddr', 'Ratio_addr',
        # 'WRatio_name', 'WRatio_nameaddr',
        'WRatio_addr',
        'Token_score_name', 'Token_score_nameaddr', 'Token_score_addr',
        '2grm_name', '2grm_addr', '2grm_nameaddr',
        '3grm_name', '3grm_addr', '3grm_nameaddr', 'token_freq'
    ]

    models = {"LogisticRegression": LogisticRegression(solver='lbfgs', max_iter=10000),
              "GradientBoostingClassifier_25": GradientBoostingClassifier(n_estimators=25),
              "RandomForestClassifier_50": RandomForestClassifier(n_estimators=50, n_jobs=-1),
              "SupportVectorMachine_rbf": SVC(kernel='rbf', probability=True)}

    model_fd = os.path.join('src', 'Models', '')

    modified_df.loc[:, 'contactName_score'] = modified_df.apply(get_token_score_contname, args=[p1], axis=1)
    scored_df1 = prediction(modified_df, models, pred_var, model_fd)

    scored_df2_aa = ensembe_score(scored_df1)
    scored_df2_aa1 = scored_df2_aa[~(scored_df2_aa['Final_Approval_Probability'] >= ml_threshold_y_lower)]
    scored_df2_aa2 = scored_df2_aa[(scored_df2_aa['Final_Approval_Probability'] >= ml_threshold_y_lower)]
    scored_df2_boost = deterministics_boosting(scored_df2_aa1, p1)
    
    scored_combined = pd.concat([scored_df2_aa2, scored_df2_boost])
    scored_combined['AddressMatch_score'] = scored_combined['Token_score_addr']
    scored_combined['NameMatch_score'] = scored_combined['Token_score_name']
    scored_combined.loc[((scored_combined[p1.fulladdr1] == ' ') | (scored_combined[p1.fulladdr2] == ' ')), 'AddressMatch_score'] = 0
    
    scored_final = flags(scored_combined, ml_threshold_y_lower, ml_threshold_a_lower)

    data2 = dataframe_to_json(data, scored_final)
    data2['input_list'].sort(key=lambda x: x['ml_score'], reverse=True)

    end = time.time()
    print("Time taken in seconds = {}".format(end - start_time))

    return data2


