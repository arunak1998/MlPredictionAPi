from django.http import HttpResponse
from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.serializers import Serializer
from rest_framework.decorators import parser_classes
from rest_framework.parsers import FileUploadParser
from src.scoring_whitespace import *
from src.training_whitespace import *
import csv
import pandas as pd


# Create your views here.
@api_view(['GET', 'POST'])
def api_whitespace_training(request):
    response_dict = {}
    if request.method == 'GET':
        # Do nothing
        pass
    elif request.method == 'POST':
        response_dict = training_main()
    return Response(response_dict, status=status.HTTP_201_CREATED)


@api_view(['GET', 'POST'])
def api_whitespace(request):
    response_dict = {}
    if request.method == 'GET':
        # Do nothing
        pass
    elif request.method == 'POST':
        data = request.data
        if len(data['input_list']) > 0:
            response_dict = scoring_main(data)
        else:
            print('Data input_list is empty. Please pass valid input for processing.')
    return Response(response_dict, status=status.HTTP_200_OK)
