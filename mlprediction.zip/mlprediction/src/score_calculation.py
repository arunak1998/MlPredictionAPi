"""
This module contains a function that calculates all the ratios needed in MDM project.
"""

from src.score_funcs import *
import pandas as pd


def name_match(df, p1):
    """
        This function calculates all the ratios needed.

        In this project, string-matching ratios are used as predictors, they are as follows:
        1. fuzz.ratio from Fuzzywuzzy
        2. fuzz.WRatio from Fuzzywuzzy
        3. fuzz.token_sort_ratio from Fuzzywuzzy
        3. 2grm ratio: This is a customised ratio with a combination of tf-idf, n-gram and cosine similarity
        4. 3grm ratio: This is a customised ratio with a combination of tf-idf, n-gram and cosine similarity

        Here, the data frame has been sliced and processed for faster processing.

        :param df: Pandas data frame
        :return: Pandas data frame with all the ratios determined
        """

    columns = (
        'Ratio_name', 'Ratio_nameaddr', 'Ratio_addr',
        'WRatio_name', 'WRatio_nameaddr', 'WRatio_addr',
        'Token_score_name', 'Token_score_nameaddr', 'Token_score_addr'
    )


    functions = (
        get_ratio_name, get_ratio_nameaddr, get_ratio_addr,
        get_wratio_name, get_wratio_nameaddr, get_wratio_addr,
        get_token_score_name, get_token_score_nameaddr, get_token_score_addr
    )

    df_for_ratios = df[[p1.fullname1, p1.fullname2, p1.fulladdr1, p1.fulladdr2, p1.fullnameaddr1, p1.fullnameaddr2]]

    df_for_ratios.fillna('', inplace=True)

    for column, func in zip(columns, functions):
        df_for_ratios.loc[:, column] = df_for_ratios.apply(func, args=[p1], axis=1)

    processed_df1 = pd.concat([df, df_for_ratios[list(columns)]], axis=1)
    del df_for_ratios, df

    # logging.info("Now tf_idf...")

    df_for_ratios_name = processed_df1[[p1.fullname1, p1.fullname2,'Ratio_name','WRatio_name','Token_score_name']]
    df_for_ratios1 = df_for_ratios_name.apply(score_name, args=[p1], axis=1)
    print(df_for_ratios1)

    df_for_ratios_addr = processed_df1[[p1.fulladdr1, p1.fulladdr2]]
    df_for_ratios2 = df_for_ratios_addr.apply(score_addr, args=[p1], axis=1)

    df_for_ratios_name_addr = processed_df1[[p1.fullnameaddr1, p1.fullnameaddr2]]
    df_for_ratios3 = df_for_ratios_name_addr.apply(score_name_addr, args=[p1], axis=1)

    df_for_ratios = pd.concat([df_for_ratios1, df_for_ratios2, df_for_ratios3], axis=1)
    del df_for_ratios1, df_for_ratios2, df_for_ratios3

    ls = ['2grm_name', '2grm_addr', '2grm_nameaddr',
          '3grm_name', '3grm_addr', '3grm_nameaddr']

    processed_df2 = pd.concat([processed_df1, df_for_ratios[ls]], axis=1)

    return processed_df2, p1