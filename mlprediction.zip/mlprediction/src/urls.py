from django.urls import path
from django.contrib import admin
import src.views as views


urlpatterns = [
    path('mlprediction/admin/', admin.site.urls),
    path('mlprediction/match', views.api_whitespace, name='api_whitespace'),
    path('mlprediction/train-model', views.api_whitespace_training, name='api_whitespace_training')
]
