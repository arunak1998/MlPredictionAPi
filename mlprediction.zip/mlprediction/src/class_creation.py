
class Columns_training(object):
    def __init__(self, cols):
        self.fullname1 = cols[0]
        self.fulladdr1 = cols[1]
        self.fullname2 = cols[2]
        self.fulladdr2 = cols[3]
        self.rtoken = cols[4]
        self.target = cols[5]

    def newAttr_training(self, attr):
        setattr(self, attr, attr)


class Columns_scoring(object):
    def __init__(self, cols):
        self.fullname1 = cols[0]
        self.fulladdr1 = cols[1]
        self.fullname2 = cols[2]
        self.fulladdr2 = cols[3]
        self.rtoken = cols[4]
        self.prntduns1 = cols[5]
        self.ultprtduns1 = cols[6]
        self.contact1 = cols[7]
        self.phone1 = cols[8]
        self.url1 = cols[9]
        self.prntduns2 = cols[10]
        self.ultprtduns2 = cols[11]
        self.contact2 = cols[12]
        self.phone2 = cols[13]
        self.url2 = cols[14]

    def newAttr(self, attr):
        setattr(self, attr, attr)