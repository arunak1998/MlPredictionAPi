import os
import re
import time
import warnings
import pandas as pd
from src.score_funcs import *
from src.score_calculation import *
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC


def training_data_transformation(df, p1):
    """
    a. Creating new columns for our processing
    b. Name Standardization applied: Converting French characters to English characters
    c. Address standardisation applied are:
        1) Converting French characters to English characters
        2) Remove all unneeded junk, i.e.everything but letters, numbers, spaces, single apostrophes, and forward slashes
        3) Remove stop words(only on addr_line_one, standardize_name already have the stop words removed)
        4) Remove 1 letter word
        5) Remove all street / avenue / boulevard / etc short ang longform, except ST
        6) Update SAINT, SAINTE and STE to ST
        7) Remove the word "ST" or "DR" if it appears at the very end of the string
        8) Update double++ spaces to 1 space
    """

    df[p1.fullname1] = df[p1.fullname1].astype('str').str.replace('nan', '', case=False)\
        .str.translate(str.maketrans('ÇÁÀÄÂÉÈËÊÍÌÏÎÓÒÖÔÚÙÜÛ', 'CAAAAEEEEIIIIOOOOUUUU')) \
        .str.replace(r"[^A-Za-z_0-9''\/\s]", " ")\
        .str.upper()

    df[p1.fullname2] = df[p1.fullname2].astype('str').str.replace('nan', '', case=False)\
        .str.translate(str.maketrans('ÇÁÀÄÂÉÈËÊÍÌÏÎÓÒÖÔÚÙÜÛ', 'CAAAAEEEEIIIIOOOOUUUU')) \
        .str.replace(r"[^A-Za-z_0-9''\/\s]", " ")\
        .str.upper()

    df[p1.fulladdr1] = df[p1.fulladdr1].astype('str').str.replace('nan', '', case=False)\
        .str.translate(str.maketrans('ÇÁÀÄÂÉÈËÊÍÌÏÎÓÒÖÔÚÙÜÛ', 'CAAAAEEEEIIIIOOOOUUUU'))\
        .str.replace(r"[^A-Za-z_0-9''\/\s]", " ") \
        .str.replace(r'(\b)(AN|AND|BRANCH|CO|DE|DES|DU|EN|ET|FOR|FP|LA|LE|LES|'
                     r'OF|SS|THE|TR|VM|ABM|BR|CC|IN|BOUL|BLV|BLVD|RD|BOULEVARD|'
                     r'RUE|STREET|AVE|AVENUE|AV|CH|CHEMIN|RTE|ROUTE|CRT|COURT'
                     r')(\b)', '', case=re.IGNORECASE) \
        .str.replace(r'\b[a-zA-Z]{1}\b', ' ', case=re.IGNORECASE) \
        .str.replace(r'\b(BUREAU|SUITE|UNIT)\b (\b[0-9]+\b)', ' ', case=re.IGNORECASE)\
        .str.replace(r'\b(SAINT|SAINTE|STE)\b', 'ST', case=re.IGNORECASE)\
        .str.replace(r'( ST| DR)$', '', case=re.IGNORECASE)\
        .str.replace(r'\s+', ' ', case=re.IGNORECASE)\
        .str.upper()

    df[p1.fulladdr2] = df[p1.fulladdr2].astype('str').str.replace('nan', '', case=False)\
        .str.translate(str.maketrans('ÇÁÀÄÂÉÈËÊÍÌÏÎÓÒÖÔÚÙÜÛ', 'CAAAAEEEEIIIIOOOOUUUU'))\
        .str.replace(r"[^A-Za-z_0-9''\/\s]", " ") \
        .str.replace(r'(\b)(AN|AND|BRANCH|CO|DE|DES|DU|EN|ET|FOR|FP|LA|LE|LES|'
                     r'OF|SS|THE|TR|VM|ABM|BR|CC|IN|BOUL|BLV|BLVD|RD|BOULEVARD|'
                     r'RUE|STREET|AVE|AVENUE|AV|CH|CHEMIN|RTE|ROUTE|CRT|COURT'
                     r')(\b)', '', case=re.IGNORECASE) \
        .str.replace(r'\b[a-zA-Z]{1}\b', ' ', case=re.IGNORECASE) \
        .str.replace(r'\b(BUREAU|SUITE|UNIT)\b (\b[0-9]+\b)', ' ', case=re.IGNORECASE)\
        .str.replace(r'\b(SAINT|SAINTE|STE)\b', 'ST', case=re.IGNORECASE)\
        .str.replace(r'( ST| DR)$', '', case=re.IGNORECASE)\
        .str.replace(r'\s+', ' ', case=re.IGNORECASE)\
        .str.upper()

    df['Name_Address_1'] = (df[p1.fullname1].astype('str').str.cat(df[[p1.fulladdr1]].astype('str'), sep=' ')
                               ).str.replace('nan', '', case=False)

    df['Name_Address_2'] = (df[p1.fullname2].astype('str').str.cat(df[[p1.fulladdr2]].astype('str'), sep=' ')
                             ).str.replace('nan', '', case=False)

    # Setting a new attribute of the instance
    setattr(p1, "fullnameaddr1", "Name_Address_1")
    setattr(p1, "fullnameaddr2", "Name_Address_2")

    return df, p1


def training_main():
    start_time = time.time()
    warnings.filterwarnings("ignore")

    # Loading data
    df = pd.read_csv(os.path.join('src', 'WhitespaceTrainingdata_UAT.csv'))

    df.columns = df.columns.str.upper()

    df = df[['NAME_1', 'ADDRESS_1', 'SUSPECT_NAME', 'SUSPECT_ADDRESS', 'TOKEN_SCORE', 'APPROVAL']]

    p1 = Columns_training(df.columns)

    df1, p1 = training_data_transformation(df, p1)

    df1.fillna('', inplace=True)

    df1['APPROVAL_ORIGINAL'] = df1['APPROVAL']

    modified_df, p1 = name_match(df1, p1)

    modified_df2 = modified_df[(modified_df[p1.target] == 'Y') | (modified_df[p1.target] == 'N')
                               | (modified_df[p1.target] == 'A')]
    
    modified_df2.drop_duplicates(inplace=True, keep='first')
    print(modified_df2['APPROVAL'])
    print("Modelling...")

    pred_var = [
        'Ratio_name', 'Ratio_nameaddr', 'Ratio_addr',
        # 'WRatio_name', 'WRatio_nameaddr',
        'WRatio_addr',
        'Token_score_name', 'Token_score_nameaddr', 'Token_score_addr',
        '2grm_name', '2grm_addr', '2grm_nameaddr',
        '3grm_name', '3grm_addr', '3grm_nameaddr', 'TOKEN_SCORE'
    ]

    target_var = p1.target
    print(target_var)

    models = {"LogisticRegression": LogisticRegression(solver='lbfgs', max_iter=10000),
              "RandomForestClassifier_50": RandomForestClassifier(n_estimators=50, n_jobs=-1),
              "GradientBoostingClassifier_25": GradientBoostingClassifier(n_estimators=25),
              "SupportVectorMachine_rbf": SVC(kernel='rbf', probability=True)}

    model_fd = os.path.join('src', 'Models', '')
    training_df = training(modified_df2, models, pred_var, target_var, model_fd)
    training_df.to_csv(os.path.join('src', 'Models', 'Training_output_UAT.csv'), index=False)

    end = time.time()
    print("Time taken in seconds = {}".format(end - start_time))

