"""
This module contains functions for Json transformations.
"""

from src.score_funcs import *
import pandas as pd


def json_to_dataframe(data):
    """
    Convert a json dictionary into pandas dataframe
    :param data: Json data
    :return: Pandas dataframe
    """
    df = pd.json_normalize(data['input_list'])
    needed_col = ['input_record.record.stdOrgName', 'input_record.record.stdAddress.combinedAddress',
                  'suspect_record.record.stdOrgName', 'suspect_record.record.stdAddress.combinedAddress', 'token_freq',
                  'input_record.record.parent_duns', 'input_record.record.utl_parent_duns',
                  'input_record.record.customer_prime_contact', 'input_record.record.customer_phone',
                  'input_record.record.customer_url', 'suspect_record.record.parent_duns',
                  'suspect_record.record.utl_parent_duns', 'suspect_record.record.customer_prime_contact',
                  'suspect_record.record.customer_phone', 'suspect_record.record.customer_url'
                  ]
    actual_col = df.columns
    missing_col = list(set(needed_col) - set(actual_col))

    # add an empty columns
    df2 = df.reindex(df.columns.tolist() + missing_col, axis=1)
    df3 = df2[needed_col]
    df3.fillna(' ', inplace=True)
    return df3


def dataframe_to_json(data, result_df):
    """
    Function to update the input json data with results of ML
    :param data: input json
    :param result_df: result dataframe of ML Script
    :return: Output json
    """
    for i in range(len(data['input_list'])):
        data['input_list'][i]['ml_score'] = result_df['Final_Approval_Probability'][i]
        data['input_list'][i]['ml_flag'] = result_df['Predicted_flag'][i]
        data['input_list'][i]['address_match_score'] = result_df['AddressMatch_score'][i]
        data['input_list'][i]['name_match_score'] = result_df['NameMatch_score'][i]
    return data