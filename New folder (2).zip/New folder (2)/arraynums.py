import numpy as np


arr = np.array([2, 1, 5, 3, 7, 4, 6, 8])

nb=np.sort(arr)
bb=np.ones(2)
print(bb)