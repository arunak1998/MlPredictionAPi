import pandas as pd
import numpy as np

# Define the number of rows
num_rows = 500

# Generate random categorical data
categories = ['Sex', 'Country', 'City', 'Name']
cat_data = np.random.choice(categories, size=(num_rows, 14))
print(cat_data)

# Generate random numerical data
num_data = np.random.randn(num_rows, 14)
print(num_data)
# Create a DataFrame
df = pd.DataFrame(np.concatenate([cat_data, num_data], axis=1))

# Assign column names
columns = [f'Column_{i}' for i in range(1, 15)]
df.columns = columns

print(df)