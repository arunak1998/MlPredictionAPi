import cx_Oracle
import json


conn = cx_Oracle.connect('username/password@hostname:port/service_name')


cursor = conn.cursor()

cursor.execute("SELECT table_name FROM all_tables WHERE owner = 'YOUR_SCHEMA'")
tables = [row[0] for row in cursor.fetchall()]

metadata = {}
for table in tables:
    # Query columns for each table
    cursor.execute(f"SELECT column_name, data_type FROM all_tab_columns WHERE table_name = '{table}'")
    columns = {row[0]: row[1] for row in cursor.fetchall()}
    
    # Query constraints for each table (e.g., primary keys)
    cursor.execute(f"SELECT constraint_name FROM all_constraints WHERE table_name = '{table}' AND constraint_type = 'P'")
    primary_key = [row[0] for row in cursor.fetchall()]
    
    # Construct table metadata object
    metadata[table] = {
        "columns": columns,
        "primary_key": primary_key
    }

# Close cursor and connection
cursor.close()
conn.close()

# Serialize metadata to JSON
metadata_json = json.dumps(metadata, indent=4)

# Save metadata to a file
with open('metadata.json', 'w') as file:
    file.write(metadata_json)
