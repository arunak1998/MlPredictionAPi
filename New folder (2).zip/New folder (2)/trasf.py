import re
import json






def modify_sql_statements(config_data, ids):
    modified_data = re.sub(r'statement\s*=>\s*"(.*?)"', lambda match: modify_statement(match.group(1), ids), config_data)
    return modified_data

def modify_statement(statement, ids):
    statement = statement.replace('"', '\\"')  
    statement=statement.upper()
    statement = statement.split('ORDER BY')[0].strip()
    mainid = statement.split(' ')[1].split(',')[0] 
   
   
    if 'WHERE' in statement:  
          if f'WHERE {mainid}' in statement:
            statement = re.sub(rf'WHERE\s+{re.escape(mainid)}\s*=\s*\'?\d+\'?', '', statement) 
            return 'statement => "{} WHERE {} IN ({}) ORDER BY {}"'.format(statement, mainid, ", ".join([f"'{id}'" for id in ids]), mainid)
          elif f'AND {mainid}' in statement:
            statement = re.sub(rf'AND\s+{re.escape(mainid)}\s*=\s*\'?\d+\'?', '', statement) 
            return 'statement => "{} AND {} IN ({}) ORDER BY {}"'.format(statement, mainid, ", ".join([f"'{id}'" for id in ids]), mainid)
          else:

                
           return 'statement => "{} AND {} IN ({}) ORDER BY {}"'.format(statement, mainid, ", ".join([f"'{id}'" for id in ids]), mainid)
    else:  
         return 'statement => "{} WHERE {} IN ({}) ORDER BY {}"'.format(statement, mainid, ", ".join([f"'{id}'" for id in ids]), mainid)
         

def trasform():
    json_data ='''[ "1002454828","1002669037",
                "1007374657",
                "1010780172",
                "1010780184",
                "1010879707",
                "1011064127",
                "1057761994",
                "1011286681",
                "1057360939",
                "1057754556",
                "1007336605",
                "1009525165",
                "1010780197",
                "1057762031",
                "1002460152",
                "1007609291",
                "1009529753",
                "1057361002",
                "1057773581",
                "1057761978",
                "1002545915",
                "1008094382",
                "1009476245",
                "1009496856",
                "1009547906",
                "1010780193",
                "1010780191",
                "1010780181",
                "1010979919",
                "1011086033",
                "1057360925",
                "1057360934",
                "1057360946",
                "1057754529",
                "1010780179",
                "1010780173",
                "1010780192",
                "1010780200",
                "1011053234",
                "1057362975",
                "1057360948",
                "1057773591",
                "1057754560",
                "1057754448",
                "1057754507",
                "1057761980",
                "1002459917",
                "1010780183",
                "1010780178",
                "1010780177",
                "1010780176",
                "1010780194",
                "1011001560",
                "1011033590",
                "1011128979",
                "1057773590",
                "1057773592",
                "1057358401",
                "1057773583",
                "1057754537",
                "1057761979",
                "1057754551",
                "1057775224",
                "1002668945",
                "1010780190",
                "1011037529",
                "1011092211",
                "1057361001",
                "1057360947",
                "1057363974",
                "1057754552",
                "1002545847",
                "1057761973",
                "1007347347",
                "1009509222",
                "1009493274",
                "1010780201",
                "1010780180",
                "1010780189",
                "1057361003",
                "1057361004"
            ]'''
    ids = json.loads(json_data)

   
    config_file_path = 'C:\\Users\\101730\\Downloads\\New folder (2)\\input.conf'
    config_file_path1 = 'C:\\Users\\101730\\Downloads\\New folder (2)\\modified.conf'
    with open(config_file_path, 'r') as file:
        config_data = file.read()

    modified_config_data = modify_sql_statements(config_data, ids)

   

  
    with open(config_file_path1, 'w') as file:
        file.write(modified_config_data)



if __name__=='__main__':
    trasform()