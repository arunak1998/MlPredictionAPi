import re

def orgname_standardization(orgname):
    # Step 0: Convert everything to uppercase
    inputorgname=orgname = orgname.upper()
    orgname = orgname.upper()

    # Step 1: Replace website addresses with spaces
    orgname = re.sub(r'\.', ' ', orgname)

    # Step 2: Remove specific words and text after them
    orgname = re.sub(r'((ATTN:|ATTN|ATTENTION|C/O|O/A|A/S|DBA|RE:|%).*)', ' ', orgname)

    orgname = re.sub('&AMP;|&', 'AND', orgname)
    orgname = re.sub('[&!@#$%^*()_+\-=\[\]{}\'|;:",.<>?]+', ' ', orgname)

    orgname = orgname.replace('\\', ' ')

    orgname = re.sub(r'[^a-zA-Z0-9- Éé Èè Êê Ëë Àà Ââ Ã Îî Ïï Ôô Çç \[ Ÿÿ Ùù Ûû Üü ä L\' ö \\\\ æ $ % ; \' ’ \\] | + { } ! & # ^ ( ) : / . , @ "]', ' ', orgname).strip()

    # Step 7: Replace words as per the provided pair mapping
    orgname = remove_single_char_space(orgname)
    orgname = re.sub(r'\b/\b', ' / ', orgname)

    # replacing company names
    orgname = company_name_std(orgname)

    # replace 2 or more spaces in between a word into a single space at last
    orgname = re.sub(r'\s{2,}', ' ', orgname).strip()
    if not orgname:
        orgname = inputorgname.upper()
    print(orgname)
    print(orgname)

    return orgname


def company_name_std(orgname):
    orgname = re.sub('BUILDING', 'BLDG', orgname)
    orgname = re.sub('INDUSTRIEL', 'INDUSTRIES', orgname)

    orgname = re.sub('ALBERTAL', 'ALBERTA', orgname)
    orgname = re.sub('ACCOUNTS', 'ACCOUNT', orgname)
    orgname = re.sub('PRINCIPALE', 'PRINCIPLE', orgname)
    orgname = re.sub('CORPORATION', 'CORP', orgname)
    orgname = re.sub('LIMITED|LTEE', 'LTD', orgname)
    orgname = re.sub('INCORPORATED', 'INC', orgname)
    orgname = re.sub('INSURANCE', 'INS', orgname)
    orgname = re.sub('MANAGEMENT', 'MGMT', orgname)
    orgname = re.sub('ASSOCIATES', 'ASSOCS', orgname)

    orgname = re.sub('UNIVETSITY|UNVIERSITY|UNIVERSIT|\\bUNIV\\b', 'UNIVERSITY', orgname)

    orgname = re.sub('ACCOUNTANT', 'ACCOUNTANCY', orgname)
    orgname = re.sub('SVCS', 'SERVICES', orgname)
    orgname = re.sub('CENTRE|CTR', 'CENTER', orgname)

    orgname = re.sub('NATIONAL', 'NATL', orgname)
    orgname = re.sub('NTWK', 'NETWORK', orgname)
    orgname = re.sub('\\bSERV\\b', 'SERVICE', orgname)
    orgname = re.sub('MOUNTAIN', 'MOUNTAINS', orgname)
    orgname = re.sub('MANUFACTURING', 'MFG', orgname)
    orgname = re.sub('DEVELOPMENT', 'DEV', orgname)
    orgname = re.sub('ADMINISTRATION', 'ADMIN', orgname)
    orgname = re.sub('HUMAINES', 'HU', orgname)
    orgname = re.sub('FINANCIAL', 'FNCL', orgname)
    orgname = re.sub('FINANCE', 'FIN', orgname)
    orgname = re.sub('EQUIPMNT', 'EQUIPMENT', orgname)
    orgname = re.sub('EMPLOYEE', 'EMP', orgname)
    orgname = re.sub('COMPANY', 'CO', orgname)
    orgname = re.sub('PROFESSION', 'PROFESSIONAL', orgname)
    orgname = re.sub('LABORATORIES', 'LABS', orgname)

    return orgname


def remove_single_char_space(orgname):
    orgname_array = orgname.split(" ")
    x = 0
    new_orgname = " "
    size_1_char = False

    while x < len(orgname_array):
        if size_1_char and len(orgname_array[x]) == 1:
            new_orgname += orgname_array[x]
        else:
            if len(orgname_array[x]) == 1:
                new_orgname += orgname_array[x]
            else:
                new_orgname += ' ' + orgname_array[x]
        if len(orgname_array[x]) == 1:
            size_1_char = True
        else:
            size_1_char = False

        x += 1

    return new_orgname.strip()


# Example usage:
orgname_standardization("Arun")