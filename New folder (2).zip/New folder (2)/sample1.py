import pandas as pd
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import  xgboost as xgb
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
# Define a function to extract values from the text
def extract_values(row):
    s = row['text'].lower()
   
    company_name, address, email, phone = s.split('. ')
    parts = address.split(", ")
    street_number = parts[0]
    street_name = parts[1]
    city = parts[2]
    country = parts[3]
    email_domain = email.split('@')[1]
    phone_split = phone.split('-')
    phone_country_code = phone_split[0]
    phone_area_code = phone_split[1]
    phone_local_number = phone_split[2]
    company_name_length = len(company_name)
    address_length = len(address)
    domain_length = len(email_domain)
    
    return pd.Series([company_name, street_number, street_name, city, country, email_domain,
                      phone_country_code, phone_area_code, phone_local_number,
                      company_name_length, address_length, domain_length])

# Apply the extraction function to each row and add the extracted values as new columns


# top_companies = [
#     "Google Corporation",
#     "Apple Inc.",
#     "Microsoft Corporation",
#     "Amazon.com Inc.",
#     "Meta Facebook Inc",
#     "Alphabet Inc.",
#     "Tesla Inc.",
#     "Walmart Inc.",
#     "Berkshire Hathaway Inc.",
#     "Johnson & Johnson",
#     "JPMorgan Chase & Co.",
#     "Exxon Mobil Corporation",
#     "Bank of America Corp.",
#     "Visa Inc.",
#     "Procter & Gamble Co.",
#     "Mastercard Incorporated",
#     "Home Depot Inc.",
#     "Intel Corporation",
#     "Verizon Communications Inc.",
#     "Netflix Inc.",
#     "Cisco Systems Inc.",
#     "AT&T Inc.",
#     "Pfizer Inc.",
#     "Adobe Inc.",
#     "Walt Disney Company",
#     "Salesforce.com Inc.",
#     "McDonald's Corporation",
#     "Abbott Laboratories",
#     "Coca-Cola Company",
#     "Oracle Corporation",
#     "Nike Inc.",
#     "IBM",
#     "NVIDIA Corporation",
#     "Chevron Corporation",
#     "Comcast Corporation",
#     "Merck & Co.",
#     "Wells Fargo & Co.",
#     "AbbVie Inc.",
#     "UPS",
#     "Accenture plc",
#     "The Goldman Sachs Group Inc.",
#     "3M Company",
#     "General Motors Company",
#     "Union Pacific Corporation",
#     "American Express Company",
#     "Costco Wholesale Corporation",
#     "Honeywell International Inc.",
#     "UnitedHealth Group Incorporated",
#     "Abbott Laboratories"
# ]

# # Function to generate sample strings
# def generate_sample_string(company):
#     address = f"{random.randint(1, 999)}, {random.choice(['Main', 'Park', 'Elm', 'Cedar'])} Street, {random.choice(['Cityville', 'Townsville', 'Metropolis'])}, {random.choice(['USA', 'UK', 'CANADA'])}."
#     company_email=company.strip()
#     company_email=company_email.replace(" ",'')
#     if company_email.endswith('.'):
#         company_email = company_email[:-1]
      
#     email = f'{company_email}@{random.choice(("gmail", "yahoo", "outlook", "tesla", "apple", "meta"))}.com'
#     phone = f"+{random.randint(100, 999)}-{random.randint(100, 999)}-{random.randint(1000, 9999)}"
#     return f"{company}. {address} Email: {email}. Phone: {phone}"

# # Generate 50 samples with tier information
# samples = []
# for company in top_companies:
    
#     for _ in range(50):
#         tier = random.randint(1, 3)
#         samples.append((company, generate_sample_string(company), tier))

# # Convert to DataFrame
# df = pd.DataFrame(samples, columns=["Company", "text", "Tier"])

# df.to_csv('C:\\Users\\101730\\Downloads\\New folder (2)\\sample_data.csv')



df=pd.read_csv('C:\\Users\\101730\\Downloads\\New folder (2)\\sample_data.csv')

df.drop(columns=['Company'],inplace=True,axis=1)

df[['Company_Name', 'Street_Number', 'Street_Name', 'City', 'Country', 'Email_Domain',
    'Phone_Country_Code', 'Phone_Area_Code', 'Phone_Local_Number',
    'Company_Name_Length', 'Address_Length', 'Domain_Length']] = df.apply(extract_values, axis=1)
df['Phone_Country_Code'] = df['Phone_Country_Code'].str.replace('+', '')
# Clean and convert 'Street_Number' column to integers
df['Street_Number'] = df['Street_Number'].str.extract('(\d+)').astype(float).astype('Int64')

# Clean and convert 'Phone_Country_Code', 'Phone_Area_Code', and 'Phone_Local_Number' columns to integers
df['Phone_Country_Code'] = df['Phone_Country_Code'].str.extract('(\d+)').astype(float).astype('Int64')
df['Phone_Area_Code'] = df['Phone_Area_Code'].str.extract('(\d+)').astype(float).astype('Int64')
df['Phone_Local_Number'] = df['Phone_Local_Number'].str.extract('(\d+)').astype(float).astype('Int64')
# Define columns for standardization and TF-IDF encoding
numerical_columns = ['Street_Number', 'Phone_Country_Code', 'Phone_Area_Code', 'Phone_Local_Number', 'Company_Name_Length', 'Address_Length', 'Domain_Length']
text_columns = ['Company_Name', 'Street_Name', 'City', 'Country', 'Email_Domain']

# Standardize numerical columns



# Concatenate text data from all text columns into a single column
df['Combined_Text'] = df['Company_Name'] + ' ' + df['Street_Name'] + ' ' + df['City'] + ' ' + df['Country'] + ' ' + df['Email_Domain']

# Initialize TfidfVectorizer
tfidf_vectorizer = TfidfVectorizer()

# Apply TF-IDF encoding to the combined text data
text_features = tfidf_vectorizer.fit_transform(df['Combined_Text'])

# Create DataFrame from TF-IDF features
text_df = pd.DataFrame(text_features.toarray(), columns=tfidf_vectorizer.get_feature_names_out(), index=df.index)


df_processed = pd.concat([df[numerical_columns], text_df], axis=1)

text_df['Tier'] = df['Tier']

# Display the processed DataFrame
# print(df_processed)


X=text_df
y=text_df['Tier']
y = y - 1

# Assuming X contains your features and y contains your target variable
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

scaler = StandardScaler()
# Split the dataset into training and testing sets


# Initialize XGBoost classifier
xgb_classifier = xgb.XGBClassifier(objective='multi:softmax', num_class=len(set(y)), random_state=42)

# Train the classifier
xgb_classifier.fit(X_train, y_train)

# Predict on the testing set
y_pred = xgb_classifier.predict(X_test)

# Print classification report
print(classification_report(y_test, y_pred))
accuracy=accuracy_score(y_test,y_pred)

print(accuracy)