import json
import numpy as np
import pandas as pd

value = []
elkcompare = []

class accountcompare:
    def readinputfile():
        try:
            with open("totalelkdoc.txt",encoding="latin-1") as myjson:
                for line in myjson:
                    out = json.loads(line)
                    value.append(out)

        except:
            print("ERROR!!!")

    def checkkeys(dict,key):
        if key in dict.keys(): 
            return True
        else: 
            return False


    def formdatadictonaryelk():
        for i in range(len(value)):

            for j in range(len(value[i]['hits']['hits'])):

                if value[i]['hits']['hits'][j]['_id'] != None:
                    id = value[i]['hits']['hits'][j]['_id']  
                else:
                    id = 0

                if accountcompare.checkkeys(value[i]['hits']['hits'][j]['_source'],'goldenKey') and value[i]['hits']['hits'][j]['_source']['goldenKey'] != None:
                    gk_id = value[i]['hits']['hits'][j]['_source']['goldenKey']
                else:
                    gk_id = 0
                
                if accountcompare.checkkeys(value[i]['hits']['hits'][j]['_source'],'mainSystemInd') and value[i]['hits']['hits'][j]['_source']['mainSystemInd'] !=  None:
                    mainSystemInd = value[i]['hits']['hits'][j]['_source']['mainSystemInd']
                else:
                    mainSystemInd = 0
                
                if accountcompare.checkkeys(value[i]['hits']['hits'][j]['_source'],'superNet2Flag') and value[i]['hits']['hits'][j]['_source']['superNet2Flag'] != None:
                    superNet2Flag = value[i]['hits']['hits'][j]['_source']['superNet2Flag']
                else:
                    superNet2Flag = 0
                
                if accountcompare.checkkeys(value[i]['hits']['hits'][j]['_source'],'mainCustomerInd') and value[i]['hits']['hits'][j]['_source']['mainCustomerInd'] != None:
                    mainCustomerInd = value[i]['hits']['hits'][j]['_source']['mainCustomerInd']
                else:
                    mainCustomerInd = 0

                if accountcompare.checkkeys(value[i]['hits']['hits'][j]['_source'],'superNet2HistoryFlag') and value[i]['hits']['hits'][j]['_source']['superNet2HistoryFlag'] != None:
                    superNet2HistoryFlag = value[i]['hits']['hits'][j]['_source']['superNet2HistoryFlag']
                else:
                    superNet2HistoryFlag = 0
                
                
                elkcompare.append({'admin_client_id': id, 
                                'gk_id': gk_id, 
                                'main_maximo_ind': mainSystemInd,
                                'goa_flag': superNet2Flag, 
                                'main_cust_ind': mainCustomerInd, 
                                'superNet2HistoryFlag' : superNet2HistoryFlag})


dbcompare = []
dbvalue = []

class accountdbcompare:
    def readinputfile():
        with open("totaldbrec.txt",'r') as mydbfile:
            for line in mydbfile:
                out = json.loads(line)
                dbvalue.append(out)

    def formdbjson():

        for i in range(len(dbvalue)):

            if dbvalue[i]['id'] != None:
                id = dbvalue[i]['id']
            else:
                id = 0
            
            if dbvalue[i]['gk_id'] != None:
                gk_id = dbvalue[i]['gk_id']
            else:
                gk_id = 0

            if dbvalue[i]['main_maximo_ind'] != None:
                main_maximo_ind = dbvalue[i]['main_maximo_ind']
            else:
                main_maximo_ind = 0


            if dbvalue[i]['main_cust_ind'] != None:
                main_cust_ind = dbvalue[i]['main_cust_ind']
            else:
                main_cust_ind = 0

            if dbvalue[i]['goa_flag'] != None:
                goa_flag = dbvalue[i]['goa_flag']
            else:
                goa_flag = 0


            if dbvalue[i]['history_goa_flag'] != None:
                history_goa_flag = dbvalue[i]['history_goa_flag']
            else:
                history_goa_flag = 0

            dbcompare.append({'admin_client_id': id, 
                                'gk_id': gk_id, 
                                'main_maximo_ind': main_maximo_ind,
                                'goa_flag': goa_flag, 
                                'main_cust_ind': main_cust_ind, 
                                'superNet2HistoryFlag' : history_goa_flag})


class externalfunctions:

    def compareaccountdata(df1,df2):

        columns_to_compare = ['admin_client_id','gk_id','main_maximo_ind','goa_flag','main_cust_ind','superNet2HistoryFlag']


        # merged = pd.merge(df1, df2, on='admin_client_id', suffixes=('_df1', '_df2'))
        # mismatched_rows = merged[merged.apply(lambda row: any(row[f'{col}_df1'] != row[f'{col}_df2'] for col in columns_to_compare), axis=1)]
        # mismatched_ids = mismatched_rows['admin_client_id'].tolist()
        # Find mismatched IDs using boolean indexing


        mask = ~(df1[columns_to_compare].isin(df2[columns_to_compare])).any(axis=1)
        mismatched_ids = df1.loc[mask, 'admin_client_id'].tolist()

        print("Mismatched IDs:")
        
        print(len(mismatched_ids))

       


            
if __name__ == '__main__':

    
    accountcompare.readinputfile()
    accountcompare.formdatadictonaryelk()
    elkdata = pd.DataFrame(elkcompare)
    print(elkdata.shape)

    accountdbcompare.readinputfile()
    accountdbcompare.formdbjson()

    dbdata = pd.DataFrame(dbcompare)

    print(dbdata.shape)

    #columns_to_compare = ['gk_id','main_maximo_ind','goa_flag','main_cust_ind','superNet2HistoryFlag']

    gk_id = elkdata[~elkdata['gk_id'].isin(dbdata['gk_id'])]
    main_maximo_ind = elkdata[~elkdata['main_maximo_ind'].isin(dbdata['main_maximo_ind'])]
    goa_flag = elkdata[~elkdata['goa_flag'].isin(dbdata['goa_flag'])]
    main_cust_ind = elkdata[~elkdata['main_cust_ind'].isin(dbdata['main_cust_ind'])]
    superNet2HistoryFlag = elkdata[~elkdata['superNet2HistoryFlag'].isin(dbdata['superNet2HistoryFlag'])]
    admin_client_id = elkdata[~elkdata['admin_client_id'].isin(dbdata['admin_client_id'])]

    print(gk_id.shape)
    print(main_maximo_ind.shape)
    print(goa_flag.shape)
    print(main_cust_ind.shape)
    print(superNet2HistoryFlag.shape)
    print(admin_client_id.shape)

    gk_id = gk_id['admin_client_id'].tolist()
    main_maximo_ind = main_maximo_ind['admin_client_id'].tolist()
    goa_flag = goa_flag['admin_client_id'].tolist()
    main_cust_ind = main_cust_ind['admin_client_id'].tolist()
    superNet2HistoryFlag = superNet2HistoryFlag['admin_client_id'].tolist()
    admin_client_id = admin_client_id['admin_client_id'].tolist()

    file = open('telephone.txt','a')
    file.writelines(str(gk_id))
    file.writelines(str(main_maximo_ind))
    file.writelines(str(goa_flag))
    file.writelines(str(main_cust_ind))
    file.writelines(str(admin_client_id))
    file.writelines(str(superNet2HistoryFlag))



    #externalfunctions.compareaccountdata(elkdata,dbdata)


    #print(datacompare.shape)


