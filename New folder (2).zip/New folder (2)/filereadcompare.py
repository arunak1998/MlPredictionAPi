import pandas as pd
import json
import re



a = []
b=[]
name_list=[]
id_list=[]
count=0
with open("D:\\elkcounts.txt",encoding="latin-1") as my_file:
   
   
    
   
    s_org_name_list = []
    org_name_list = []
    admin_client_id_list = []
    
   
    for line in my_file:
      
        data_dict = json.loads(line)
        
       
        org_name_list.append(data_dict.get('org_name'))
        admin_client_id_list.append(data_dict.get('admin_client_id'))


df = pd.DataFrame({
    
    'org_name': org_name_list,
    'admin_client_id': admin_client_id_list
})

print(df)
      
        
with open("D:\\finalresult.txt",encoding="latin-1") as my_file:
    

    for line in my_file:
      
        
       
        pattern = r'"name":"(.*?)".*?"id":"(\d+)"'
       
       
        matches = re.findall(pattern, line)

       
        for match in matches:

            if match[0]: 
                name = match[0]
                _id = match[1]
            else: 
                name = None
                _id = match[2]
                
            name_list.append(name)
            
            id_list.append(_id)



df1 = pd.DataFrame({
    'admin_client_id': id_list,
    'org_name': name_list
})

print(df1)

merged_df = pd.merge(df, df1, on='admin_client_id', suffixes=('_df1', '_df2'))
names=merged_df.iloc[:,:-1]


print(names)

# mismatched_ids_df = df[~df['admin_client_id'].isin(df1['admin_client_id'])]
# # Print the resulting DataFrame
# print(mismatched_ids_df)