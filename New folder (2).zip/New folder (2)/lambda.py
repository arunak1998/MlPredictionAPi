import pandas

add=lambda a,b:a+b

print(add(3,7))

mul=lambda x:x*3

print(mul(50))

print((lambda a:a*70+50)(50))


product=lambda x,y,z:x*y*z 
print(product(z=10,y=20,x=10))


args1=lambda *args:max(args)
print(args1(1,2,8,16,20))



higher_order=lambda x,fun:x+fun(x)

print(higher_order(20,lambda x:x*x))


# filtering condition

num=[1,2,20,40,21,50,14,85]


greater=list(filter(lambda num:num>40,num))

print(greater)



double_sum=list(map(lambda x:x*2,num))
print(double_sum)




def quadratic(a,b,c):
    return lambda 