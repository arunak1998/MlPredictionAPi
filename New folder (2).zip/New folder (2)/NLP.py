
from nltk.tokenize import sent_tokenize,word_tokenize,wordpunct_tokenize,TreebankWordTokenizer
from nltk.stem import PorterStemmer,RegexpStemmer,SnowballStemmer,WordNetLemmatizer
import nltk
import re
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer,TfidfVectorizer
import spacy

# Load the English language model
nlp = spacy.load("en_core_web_sm")


# Create CountVectorizer object
vectorizer = CountVectorizer(ngram_range=(1,3))
tdif=TfidfVectorizer()

paragraph="""The Indian economy has shown resilience amidst global challenges. With a diverse economic landscape, India boasts of a robust services sector, thriving manufacturing industries, and a burgeoning agricultural sector. However, the economy faces persistent challenges such as unemployment, inflation, and income inequality. In recent years, the government has implemented various reforms to boost economic growth and attract foreign investment. These efforts have yielded positive results, with India emerging as one of the fastest-growing major economies in the world. Despite this progress, issues like infrastructure development, bureaucratic hurdles, and regulatory uncertainties continue to hinder the economy's full potential. Nevertheless, India remains a promising market for investors, with its large consumer base and untapped opportunities. As the country strives for inclusive and sustainable development, addressing these challenges will be crucial for achieving long-term prosperity."""
sentences1="""India, a land of kaleidoscopic diversity and vibrant cultural tapestry, boasts a plethora of breathtakingly beautiful places . the places ranging from the majestic peaks of the Himalayas in the north, adorned with serene valleys and ancient monasteries, to the sun-kissed beaches of Goa in the west, where golden sands meet the azure waters of the Arabian Sea, and from the intricate architecture of the timeless Taj Mahal in Agra."""
stemmer=PorterStemmer()
snow=SnowballStemmer('english')
lemme=WordNetLemmatizer()
import datetime
sentences=sent_tokenize(sentences1)
# print(sentences)
# tag_element=nltk.pos_tag_sents(words)

# print(nltk.ne_chunk(tag_element).draw())
## Apply stop words and filer and thean apply steeming
# corpus=[]
# for i in range (len(sentences)):
#    review=re.sub('[^a-zA-Z]', ' ',sentences[i])
#    review=review.lower()
#    review=review.split()
#    review=[lemme.lemmatize(word) for word in review if word not in stopwords.words('english')]
#    review=' '.join(review)
#    corpus.append(review)
# # X=tdif.fit_transform(corpus)

# print(corpus) 
       

# print(X[0].toarray())
doc = nlp(sentences1)

# Split the paragraph into sentences
sentences2 = list(doc.sents)
corpus1=[]
for i in range (len(sentences2)):
   review = re.sub('[^a-zA-Z]', ' ', sentences2[i].text)
   review = review.lower()
   review = review.split()
   review = [token.lemma_ for token in nlp(" ".join(review)) if not (token.is_stop or token.is_punct)]
    
   review=' '.join(review)
   corpus1.append(review)


print(corpus1) 
# X=vectorizer.fit(corpus1)
X=tdif.fit_transform(corpus1)
# print(vectorizer.transform(["india tajmahal beautiful place"]).toarray())
feature_names=tdif.get_feature_names_out()
time=datetime.datetime.now()
formatted_timestamp = time.strftime("%Y-%m-%dT%H:%M:%S.%2fZ")
print(formatted_timestamp)
print(X.toarray()[:1])












# corpus='''
# I am Learning NLP and Practising it to Master in it. Please Learn the Basic's Strong! to become expert in  ML  and DL .
# '''
# ### The above is Paragraph

# print(corpus)
# ##### Paragraph to sentences 

# documents=sent_tokenize(corpus)
# for sentence in documents:
#     print(sentence)

# ##### pargarph to words 
# ##### Sentence to words 
# words=word_tokenize(corpus)
# print(words)

# for w in words:
#     print(w)


# #####wordpunct tokneize will take seprate puctuations as sperate words


# words1=wordpunct_tokenize(corpus)
# print(words1)


# ###### the full stops in the middle sentence will be come with the previous woord itself.

# tree=TreebankWordTokenizer()
# words2=tree.tokenize(corpus)
# print(words2)





# 



# ######stemming


# word_list = [
#     "Running",
#     "Runs",
#     "Ran",
#     "Runner",
#     "Running",
#     "Jumps",
#     "Jumped",
#     "Jumping",
#     "Swim",
#     "Swims",
#     "Swam",
#     "Swimming",
#     "Fish",
#     "Fishing",
#     "Fished",
#     "Fishes",
#     "Fisherman",
#     "Eat",
#     "Eats",
#     "Ate"
# ]


# stemming=PorterStemmer()
# regex=RegexpStemmer('ing$|s$|e$|able$', min=4)
# snow=SnowballStemmer('english')
# for word in word_list:
#     print(word+"-----------"+stemming.stem(word))


# for word in word_list:
#     print(word+"-----------"+regex.stem(word))

# for word in word_list:
#     print(word+"-----------"+snow.stem(word))



# lemma=WordNetLemmatizer()
# for word2 in word_list:
#     print(word2+"----lemmaa -------"+lemma.lemmatize(word2,pos="v"))





