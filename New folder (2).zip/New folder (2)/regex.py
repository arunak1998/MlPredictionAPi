import re

import spacy

s='Google Corparation. 123 Main Street, Cityville, USA. Email: example@email.com. Phone: +123-456-7890,+91-(444)-555-7777'



matches=re.findall(r'\b\w+\b',s)

email=re.findall(r'[a-zbA-Z0-9.+-]+\@[a-bA-z0-9+.]+\.[a-zA-z0-9]{2,}',s)

print(email)

phones = re.findall(r'[\+\d]{1,3}?[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}', s)
print(phones)
capital = re.findall(r'^[A-Z][^A-Z]*', s)
print(capital)


